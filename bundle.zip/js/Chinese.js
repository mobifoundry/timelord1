/**
 * @author thurberdog
 */
/**
 * 
 * Chinese (Tradional)
 * 23SEP11 Written by Louis Meadows, for SVCW 9/23/2011
 * 23SEP11 LPM SVCW requires chinese ! 

 */
// 04OCT11 LPM added MaterialUsedButton


function Chinese()
{
    uiManager.showNotification(3000, "info", TimeLord + " <br> " + LBL013  +
    VERSION.fontcolor("Green") +
    LBL005 +
    author.fontcolor("Grey") +
    "<br> &copy 2009" +
    company.fontcolor("Blue"));
   
	WARN001  = WARN001CT; //  = " Nombre d'empleado(a) o numero ";
// The parenthetical a is to provide support for a female employee.  Another plus for us!

	WARN002  = WARN002CT; //  = " Por favor introduzca un Trabajo ";

	WARN003  = WARN003CT; //   = " Comenzar a trabajar";

	WARN004  = WARN004CT; //  = " Introduzca la tarea de Trabajo para crear un golpe de lista";

	WARN005  = WARN005CT; //  = "Nombre de Trabajo nuevo o numero existente ";

	WARN006  = WARN006CT; //  = "Por favor introduzca tu Material!";

	WARN007  = WARN007CT; //  = "Por favor introduzca el precio!";

	WARN008  = WARN008CT; //  = "claro menu no hace";

	WARN009  = WARN009CT; //  = "Introduzca la tarea de Trabajo a completar";

	LBL002   = LBL002CT; //   = "<br/>Primero introduzca uno numero de Trabajo," +
                     // +" despues Tarea, Mano de obra y Materiales ";
				 
	LBL003   = LBL003CT; //   = "Introduzca Material";

	LBL004   = LBL004CT; //   = "Nombre d'empleado(a) o numero";

	LBL005   = LBL005CT; //   = "<br> Escrito Para";

	LBL006   = LBL006CT; //   = " Hoja de tiempo ";

	LBL007   = LBL007CT; //   = "Billete de Materiales: $";

// Are we going to support foreign currencies?  
// If so, maybe we need pesos or pesetas instead of dollars. RNM

	LBL008   = LBL008CT; //   = "Nombre de Materiales o numero";

	LBL009   = LBL009CT; //   = " Trabajando!";
// There's no really good translation of "Clocked in!" 
// hence I used the Spanish for "working" = Trabajando. RNM 
	LBL010   = LBL010CT; //   = "Introduzca la Cantidad";

	LBL012   = LBL012CT; //   = "Trabajo:";

	LBL014   = LBL014CT; //   = " Cantidad";

	LBL015   = LBL015CT; //   = "Precio";

	LBL016   = LBL016CT; //   = "Precio de comprar o zero si es stock ";

	LBL017   = LBL017CT; //   = "Introduzca Precio por unidad";

	LBL018   = LBL018CT; //   = "Agregar una tarea";

	LBL019   = LBL019CT; //   = "Complete tarea";

	LBL020   = LBL020CT; //   = "Tarea de Trabajo";

	LBL021   = LBL021CT; //   = " Lista de Tareas";

	LBL022   = LBL022CT; //   = "men� claro no ocurri�";

	LBL023   = LBL023CT; //   = " compleado";  // i.e. completed

	LBL024   = LBL024CT; //   = " primero person en sitio "; // i.e. first person on site

	LBL025   = LBL025CT; //   = " con la tripulacion ";
// This is a tricky one.  Literally, it becomes "Sobre tripulacion"
//  but that's like "on top of crew".  Could be bad!
// "en tripulacion" means "in crew".  
// "con la tripulacion" means "with the crew".  
// Hence I've used that.  
// Please check with your Mexican friends what they recommend.
	LBL026   = LBL026CT; //   = " Horas ";

	LBL027   = LBL027CT; //   = " Trabajos activos";

	LBL028   = LBL028CT;  //   = " Trabajo nuevo: ";

	LBL029   = LBL029CT; // = " Trabajo existente:";

	JobButtonText = JobButtonTextCT; // = "Trabajo";

	MaterialsButtonText = MaterialsButtonTextCT; // = "Materiales";
	
	MaterialUsedButtonText = MaterialUsedButtonTextCT;
	
	taskButtontext = taskButtontextCT;  // = "Lista de Tareas";

	LaborButtonText = LaborButtonTextCT;
	// Because job and labor in English both translate to trabajo in Spanish 
// I am interpeting Labor here as "effort".
// So our translation for "Labor" in English becomes "esfuerzo" 
// which literally means effort.  Is that OK?
	cinButtonText = cinButtonTextCT;  // = "Comenzar a trabajar";

	coButtonText = coButtonTextCT; // = "Trabajo terminado";
// Similar problem translating "Clock Out" to "Clock In".  
// My Spanish equates to "Work finished" = "Trabajo terminado"

	menulblabout = menulblaboutCT; // = "Sobre";

	menulblmain  = menulblmainCT; //  = "Principal";

	menulbljob   = menulbljobCT; //  = "Trabajo"; 

	menulbllabor = menulbllaborCT; // = "Esfuerzo";

	menulblmaterials = menulblmaterialsCT; // = "Materiales";

	menulblcursor = menulblcursorCT; // = "Modo cursor";

	menulbltab = menulbltabCT; // ="Modo de ficha";

	viewlblmain = viewlblmainCT; // = "Vista principal";  // I.e. Prinicipal or Main View. 

	viewlbllabor = viewlbllaborCT; // = "Vista d'Esfuerzo";  // I.e. View of Effort (Labor)

	viewlbljob = viewlbljobCT; // = "Vista des Trabajos";  // I.e. View of Jobs

	viewlbltask = viewlbltaskCT;  // = "Vista de Tareas";  // I.e. View of tasks
	
if (mainView == null) {
 	    MainView(); 
 	   }
 	   else {
   uiManager.setView(mainView);
  }
	
	}

