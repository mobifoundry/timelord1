/** * @author thurberdog */
/**  *  * C l o c k O u t  *  * Called when the clocked out button is clicked.  *  */  
//--------------------------------------------------------------------------------------//
//
// Application: TimeLord1
// Copyright: Positively Front Street, Inc
// DBA: mobiFoundry 
// Author: Louis Meadows
// Target: Nokia WRT 1.0/1.1 E51/E71/E71x mobile phone
// Default now AT&T E71x, for E51 user will need to set cursor mode in options. 
// Date: FEB 10 2010
// Description: Job Management - Time and materials application
//
// TimeLord1 is a Job based tracking of Labor, Materials and Tasks (to-do list).
// It allows a Contractor to clock in/out personnel, track materials use and 
// task completion.  Supports up to 10 job locations with employees/subcontractors,
// materials and tasks at each. Advanced version supports bluetooth/location based
// clock in/out of employees/subcontractors when all jobs must run concurrently 
// and on schedule.  Labor and Materials tracking in real time provides for maximizing
// profit by reducing these key costs. Tracking and assigning of Job tasks allows for 
// better completion estimates for builders and project planners alike. Timelord1 was
// designed to run on the Nokia E51/71 business phone. 
//
// 14JAN10 LPM split javascript file
//
// 28JAN10 LPM General clean up after v112 failed OVI QA
// 29JAN10 LPM Continued Finnish
// 30JAN10 LPM removed button and move to softkey
// 10FEB10 LPM improved clockin/clockout
// 20APR10 LPM OVI QA has asked for End Date 
//         "Dear Publisher,
//         We have added a compatible device to increase its global distribution for this content. 
//         We now have a requirement that all signed content must have an End Publish Date that is on or before the certificate’s expiry date.  
//         Since your content was published before this requirement was in effect, 
//         we are providing a 30 day window for you to add in the End Publish Date for this content. 
//         If the changes are not made after 30 days, we will be unpublishing your content. 
//         Should you have any questions, please contact the Ovi Publish Support team at PublishToOvi.Support@nokia.com.
// 
//         You can view the whole comment thread at
//         https://publish.ovi.com/download_items/show/38566
// 
//         If you have any questions, please contact us through the Support page at https://publish.ovi.com/help/feedback 
//         or email us at PublishToOvi.Support@nokia.com."
//
//         Set end date in store to April 20th 2012, two years out
//         Could not do without content getting taken down from store and new QA
//         So reviewing all modules and improving where possible
//
// 04OCT11 LPM iphone / android port continues
// 06OCT11 LPM 
// 18OCT11 LPM bb port / bug fix
// 18OCT11 LPM getting ready for blackberry port and a show pass!
//--------------------------------------------------------------------------------------// 
function ClockOut(event)

{
	
    name  = nameField.getText();
    if (name.length == "") 
	   {
        uiManager.showNotification(2000, "warning", WARN001);
		return;
        }	
   clock = new Date();
 
    hh    = Pad(clock.getHours());
    mm    = Pad(clock.getMinutes());
    ss    = Pad(clock.getSeconds());
  
		
    timestamp = hh + ":" + mm + ":" + ss;  // construct timestamp
      for (x in names) 
	    {
        x = names.indexOf(name, 0);			
        if (names[x] == name) 
             {
                Empnum = x;
                clockOutTimes[Empnum] = clock;
             }
        }	
  
    //Get elapsed time,1 day in milliseconds
    elapsedTime[Empnum] = clockOutTimes[Empnum].getTime() - clockInTimes[Empnum].getTime();
 
	if ( totaltime[Jobnum] == null ) 
	   {
       totaltime[Jobnum] = elapsedTime[Empnum];
	   }
	else 
	   {
	   totaltime[Jobnum] += elapsedTime[Empnum];
	   }
	   
    elapsedDays = Math.floor(elapsedTime[Empnum] / day);
    milliSecondsRemaining = elapsedTime[Empnum] % day;
    CalulateElapsedTime();

    if (name.length == "") 
		{
        uiManager.showNotification(3000, "warning", WARN001);
    	}
    else 
		{
        uiManager.showNotification(3000, "info",elapsedHours + LBL026 + elapsedMinutes + " Minutes " + "  " + name);
    	}

  if (EmployeePanel != null) 
            {
            EmployeePanel = new ContentPanel(null,LBL006,clockedInEmps[Jobnum] , true, false);
  	        EmployeeView.addControl(EmployeePanel);			
            }
		else
		    {
            EmployeePanel = new ContentPanel(null, WARN003 ," " ,true, false);				
            }
 if (LaborPanel != null) 
            {
            LaborPanel = new ContentPanel(null,LBL006,clockedInEmps[Jobnum] , true, false);
  	        LaborView.addControl(EmployeePanel);			
            }
		else
		    {
            LaborPanel = new ContentPanel(null, WARN003 ," " ,true, false);				
            }
  LaborLabel.setText("#" + Jobnum + " : " + Job );
  EmployeeLabel.setText("#" + Jobnum + " : " + Job );
  uiManager.setView(JobView);   
	}

