//--------------------------------------------------------------------------------------//
//
// Application: TimeLord1
// Company: Positively Front Street, Inc
// DBA: mobiFoundry 
// Author: Louis Meadows
// Target: Nokia WRT 1.0/1.1 E51/E71/E71x mobile phone
// Default now AT&T E71x, for E51 user will need to set cursor mode in options. 
// Date: Oct 2nd 2009
// Description: Job Management - Time and materials application
//
// TimeLord1 is a Job based tracking of Labor, Materials and Tasks (to-do list).
// It allows a Contractor to clock in/out personnel, track materials use and 
// task completion.  Supports up to 10 job locations with employees/subcontractors,
// materials and tasks at each. Advanced version supports bluetooth/location based
// clock in/out of employees/subcontractors when all jobs must run concurrently 
// and on schedule.  Labor and Materials tracking in real time provides for maximizing
// profit by reducing these key costs. Tracking and assigning of Job tasks allows for 
// better completion estimates for builders and project planners alike. Timelord1 was
// designed to run on the Nokia E51/71 business phone. 
// 13JAN10 Louis Meadows, updated
// 14JAN10 Louis Meadows, created seperate javascipt file
// 29MAR10 Louis Meadows corrected miss name between button and file
//
// 20APR10 LPM OVI QA has asked for End Date 
//         "Dear Publisher,
//         We have added a compatible device to increase its global distribution for this content. 
//         We now have a requirement that all signed content must have an End Publish Date that is on or before the certificate’s expiry date.  
//         Since your content was published before this requirement was in effect, 
//         we are providing a 30 day window for you to add in the End Publish Date for this content. 
//         If the changes are not made after 30 days, we will be unpublishing your content. 
//         Should you have any questions, please contact the Ovi Publish Support team at PublishToOvi.Support@nokia.com.
// 
//         You can view the whole comment thread at
//         https://publish.ovi.com/download_items/show/38566
// 
//         If you have any questions, please contact us through the Support page at https://publish.ovi.com/help/feedback 
//         or email us at PublishToOvi.Support@nokia.com."
//
//         Set end date in store to April 20th 2012, two years out
//         Could not do without content getting taken down from store and new QA
//         So reviewing all modules and improving where possible
// 21APR10 LPM Continue improving labor traking features, new screen for each employee with 
//         the clock in of out button.  A panel timesheet for each is shown
// 28JUL10 LPM Start of project mongolord
// 04OCT11 LPM continued android / iphone port
//--------------------------------------------------------------------------------------// 

function JobEntered(event) 

    {
	var y = Jobnum; 

    Job = JobField.getText();

    if (Job.length == "") 
	    {
		try {
			Immersion.worker.playEffect(33);
		}
		catch (RuntimeException)
		{
			
		}			
        uiManager.showNotification(3000, "warning", WARN002);
        uiManager.setView(mainView);
try {
  	Immersion.worker.stopEffect();
  }
  catch (RuntimeException){}		
		return;
        } 
    else 
        {
	
       if (Job.length == 1)  
		{ 
		   if ( Job == "0") 
		   {
		      Jobnum = 0;
			  Job = Jobs[0];
			  }
		   if ( Job == "1") 
		   {
		      Jobnum = 1;
			  Job = Jobs[1];
			  }	
		   if ( Job == "2") 
		   {
		      Jobnum = 2;
			  Job = Jobs[2];
			  }
		   if ( Job == "3") 
		   {
		      Jobnum = 3;
			  Job = Jobs[3];
			  }
		   if ( Job == "4") 
		   {
		      Jobnum = 4;
			  Job = Jobs[4];
			  }
		   if ( Job == "5") 
		   {
		      Jobnum = 5;
			  Job = Jobs[5];
			  }	
		   if ( Job == "6") 
		   {
		      Jobnum = 6;
			  Job = Jobs[6];
			  }
		   if ( Job == "7")
		    {
		      Jobnum = 7;
			  Job = Jobs[7];
			  }	
		   if ( Job == "8") 
		   {
		      Jobnum = 8;
			  Job = Jobs[8];
			  }
		   if ( Job == "9")
		    {
		      Jobnum = 9;
			  Job = Jobs[9];
			  }			  			 			  		  			  					  			  			  		  
		   }
		if (totalmaterials[Jobnum] == null ) 
		{
		    totalmaterials[Jobnum] = 0;
			}	
		if (totaltime[Jobnum] == null)
		 {
		    totaltime[Jobnum] = 0;
			}	

        exsitingJob = null;
        for (x in Jobs)
           {
            if ( Jobs[x] == Job ) 
			   {
			   	y = x;
                exsitingJob = Job;				
			   }
		   }
        if (exsitingJob == null ) 
		    {
			Jobcount++;
			activejobs += "#" + Jobnum + " " + Job + "<br />";
			Jobs[Jobnum] = Job;
			mainView.removeControl(infoPanel);			
			infoPanel = new ContentPanel(null,
			                             Jobcount + LBL027, 
										 activejobs, true, false);
			mainView.addControl(infoPanel);
            JobLabel.setText("#" + Jobnum +" : " + Job);			
            uiManager.showNotification(3000, "info",
			                           "#" + Jobnum + LBL028 + Job);
			totaltime[Jobnum] = 0;
		    }					  
        else 
		    {
			Jobnum = y;
            JobLabel.setText("#" + Jobnum +" : " + Job);
            uiManager.showNotification(3000, "info",
			"#" + Jobnum +  LBL029 + Job );			
			}

        JobField.value = "";						
	    }
		
      JView();
		 
	}
