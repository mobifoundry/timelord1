/** * @author thurberdog */
/**  * M a i n V i e w
  *
  * Called from the onload event handler in TimeLord.html to initialize the widget.   **/
//--------------------------------------------------------------------------------------//
//
// Application: TimeLord1
// Copyright: Positively Front Street, Inc
// DBA: mobiFoundry 
// Author: Louis Meadows
// Target: Nokia WRT 1.0/1.1 E51/E71/E71x mobile phone
// Default now AT&T E71x, for E51 user will need to set cursor mode in options. 
// Date: Oct 2nd 2009
// Description: Job Management - Time and materials application
//
// TimeLord1 is a Job based tracking of Labor, Materials and Tasks (to-do list).
// It allows a Contractor to clock in/out personnel, track materials use and 
// task completion.  Supports up to 10 job locations with employees/subcontractors,
// materials and tasks at each. Advanced version supports bluetooth/location based
// clock in/out of employees/subcontractors when all jobs must run concurrently 
// and on schedule.  Labor and Materials tracking in real time provides for maximizing
// profit by reducing these key costs. Tracking and assigning of Job tasks allows for 
// better completion estimates for builders and project planners alike. Timelord1 was
// designed to run on the Nokia E51/71 business phone. 
//
// 04Nov09 RNM added Spanish text variables - all ending in "es" the international 2 
//         character code for SPAIN (Espana)
//		   Although you sent me an example with "es" on the end of the variable name,
//		   I felt it better to capitalize this, especially thinking ahead to the 20
//		   different language versions we intend to support.  So "es" became "ES"  OK?
//
// 11Nov09 Added code to switch from English to Espana
//
// 12JAN10 Added code for switch to Swedish text provided by Niklas 
//
// 14JAN10 LPM split javascript file
//
// 28JAN10 LPM General clean up after v112 failed OVI QA
// 29JAN10 LPM Continued Finnish
// 30JAN10 LPM replaced Job button with Enter softkey
// 15FEB10 LPM improving job entery
//--------------------------------------------------------------------------------------//
//
// Application: TimeLord1
// Copyright: Positively Front Street, Inc
// DBA: mobiFoundry 
// Author: Louis Meadows
// Target: Nokia WRT 1.0/1.1 E51/E71/E71x mobile phone
// Default now AT&T E71x, for E51 user will need to set cursor mode in options. 
// Date: Nov 13th 2009
// Description: Job Management - Time and materials application
//
// TimeLord1 is a Job based tracking of Labor, Materials and Tasks (to-do list).
// It allows a Contractor to clock in/out personnel, track materials use and 
// task completion.  Supports up to 10 job locations with employees/subcontractors,
// materials and tasks at each. Advanced version supports bluetooth/location based
// clock in/out of employees/subcontractors when all jobs must run concurrently 
// and on schedule.  Labor and Materials tracking in real time provides for maximizing
// profit by reducing these key costs. Tracking and assigning of Job tasks allows for 
// better completion estimates for builders and project planners alike. Timelord1 was
// designed to run on the Nokia E51/71 business phone. 
//
// 13NOV10 LPM Add screen to select language. 
// 29JAN10 LPM Added javascript code for switch to Finnish text provided by Niklas 
// 29JAN10 LPM Continued Finnish\
// 05FEB10 LPM v121 fails to store clock in information 
// 06FEB10 LPM changed version to v122 to fix above regression 
//
// 15FEB10 LPM improving interface
// 20APR10 LPM OVI QA has asked for End Date 
//         "Dear Publisher,
//         We have added a compatible device to increase its global distribution for this content. 
//         We now have a requirement that all signed content must have an End Publish Date that is on or before the certificate’s expiry date.  
//         Since your content was published before this requirement was in effect, 
//         we are providing a 30 day window for you to add in the End Publish Date for this content. 
//         If the changes are not made after 30 days, we will be unpublishing your content. 
//         Should you have any questions, please contact the Ovi Publish Support team at PublishToOvi.Support@nokia.com.
// 
//         You can view the whole comment thread at
//         https://publish.ovi.com/download_items/show/38566
// 
//         If you have any questions, please contact us through the Support page at https://publish.ovi.com/help/feedback 
//         or email us at PublishToOvi.Support@nokia.com."
//
//         Set end date in store to April 20th 2012, two years out
//         Could not do without content getting taken down from store and new QA
//         So reviewing all modules and improving where possible
// 21JUL11 LPM removed MenuItem Nokia WRT specific code
// 04OCT11 LPM continue port to android / iphone
//--------------------------------------------------------------------------------------// 
//                             M A I N V I E W
//--------------------------------------------------------------------------------------// 

function MainView()
 {
  /* Nokia WRT specific code
  window.menu.setRightSoftkeyLabel("Enter "+JobButtonText, JobEntered );
  */ 
  Tone(); 
  if (mainView == null) 
  {
  	mainView = new ListView(MENU_ITEM_MAIN, viewlblmain);
  	aboutPanel = new ContentPanel(null, TimeLord, LBL011 +
  	                              VERSION.fontcolor("Black") +
  	                              LBL005 +
  	                              author.fontcolor("Green") +
  	                              "&copy 2009,2010" +
  	                              company.fontcolor("Purple") +
  	                              LBL001, true, false);
  	JobLabel = new Label();
  JobField        = new TextField(null, WARN005);
  mainView.addControl(JobField);
  JobButton = new FormButton(null, JobButtonText);
  JobButton.addEventListener("ActionPerformed", JobEntered );
  mainView.addControl(JobButton);   	
  	// widget.setNavigationEnabled(false);
  }
 
 
  Jobnum = Jobcount;   // point to next empty job number

    // show the main view
  uiManager.setView(mainView);	
}

