/**
 * @author thurberdog
 */

function checkDrivesInformation() {
  var space = 0;
  // get existing user's drives
  var allDrives = sysinfo.drivelist;
  var drives = allDrives.split(" ");
  // read and print all drives’ name and information
  for (var i=0; i<drives.length; i++) {
     space = sysinfo.drivesize(drives[i]);
     space /=1024; // convert from bytes to kB
     alert("Total space of drive "+drives[i]+" ="+space+"kB");
     space = sysinfo.drivefree(drives[i]);
     space /=1024; // convert from bytes to kB
     alert("Free space of drive "+drives[i]+" ="+space+"kB");
     }
  }