// Handle Loading of appMobi Library
document.addEventListener("appMobi.device.ready",ImmersionRegister,false);

function ImmersionRegister()
{
	if( AppMobi.device.platform == "Android" )
		AppMobi.device.registerLibrary("com.immersion.ImmersionModule");
}

function ImmersionLoaded()
{	
	while (Immersion._constructors.length > 0) {
		var constructor = Immersion._constructors.shift();
		try {
			constructor();
		} catch(e) {
			alert("Failed to run constructor: " + e.message);
		}
	}
    
	// all constructors run, now fire the ready event
	Immersion.available = true;
	var e = document.createEvent('Events');
	e.initEvent('immersion.ready',true,true);
	document.dispatchEvent(e);
}

// Global name-prefixed object to store initialization info
if (typeof(ImmersionInfo) != 'object')
    ImmersionInfo = {};

/**
 * This provides a global namespace for accessing information
 */
Immersion = {
    queue: {
        ready: true,
        commands: [],
        timer: null
    },
    _constructors: []
};

/**
 * Add an initialization function to a queue that ensures our JavaScript 
 * object constructors will be run only once our module has been loaded
 */
Immersion.addConstructor = function(func) {
    var state = document.readyState;
    if ( ( state == 'loaded' || state == 'complete' ) && ImmersionInfo.ready != "undefined" )
	{
		func();
	}
    else
	{
        Immersion._constructors.push(func);
	}
};

// Begin Javascript definition of Immersion.Worker which bridges to ImmersionWorker
Immersion.Worker = function() 
{
}

Immersion.Worker.prototype.playEffect = function(index)
{
    if( AppMobi.device.platform == "Android" )
        ImmersionWorker.playEffect(index);
}

Immersion.Worker.prototype.stopEffect = function()
{
    if( AppMobi.device.platform == "Android" )
        ImmersionWorker.stopEffect();
}

Immersion.addConstructor(function() {
    if (typeof Immersion.worker == "undefined") Immersion.worker = new Immersion.Worker();
});

// Begin Javascript definition of Immersion.Setup which bridges to ImmersionSetup
Immersion.Setup = function() 
{
    this.ready = null;
    try 
    {
        this.ready = ImmersionInfo.ready;
    } 
    catch(e) 
    {
    }
}

Immersion.addConstructor(function() {
    if (typeof Immersion.setup == "undefined") Immersion.setup = new Immersion.Setup();
});

