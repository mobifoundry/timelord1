//**
// * @author thurberdog
// */
// 13AUG11 LPM create init to better initilize timelord 1 
var so = null;
function init()
{
   setTimeout("LanguageSelect();", 3000);
//   currentScreenView = "splashScreenView";
   // document.getElementById('splashScreenView').setAttribute("class", "view");
   h = document.getElementById('TimeLord1').clientHeight;
   w = document.getElementById('TimeLord1').clientWidth;
 
   
  	if ( uiManager == null ) 
	  {
      uiManager = new UIManager(); // create User Interface
      
      uiManager.showNotification(3000, "info", TimeLord + " <br> " + LBL013  +
                                 VERSION.fontcolor("Red") + LBL005 + author.fontcolor("Green") +
                                 "&copy 2009,2010,2011" + company.fontcolor("Blue"));
      } 

   
 // Assign event handler to the onresize event
  window.onresize = windowResized;
 
  // Called when the window is resized
 
}
 function windowResized() {
    // Add code to do following:
    //  1) detect screen size 
    //  2) switch to correct view and 
    //  3) set active style sheet
}   